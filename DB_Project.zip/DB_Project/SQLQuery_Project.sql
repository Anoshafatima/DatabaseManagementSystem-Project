create database HealthManagement
create table Patients(
IdPatients int primary key,
Patient_Name varchar(50) not null,
Age int not null,
Weightkg float not null,
Height float not null,
Contactno int not null,
Is_Alive bit not null,
Gender varchar(30) not null,
Addresshome varchar(100) not null
)
create table Login_details(
id_Login int primary key,
Username varchar(50) not null,
Pass varchar(50) not null,
Designation varchar(30) not null,
Doctors_id int not null,
foreign key (Doctors_id) references Doctors (id_doctors) on delete cascade
)
create table Doctors(
id_doctors int primary key,
Doc_Name varchar(50) not null,
Specialty varchar(50) not null,
Experience int not null,
Education varchar(150) not null,
doc_Specialty int not null,
foreign key (doc_Specialty) references Specialties (id_specialty) on delete cascade
)
create table Specialties(
id_specialty int primary key,
Specialty varchar(60) not null
)

Alter table Doctors
Add doctor_loginid int not null
ALTER TABLE Doctors
ADD FOREIGN KEY (doctor_loginid) REFERENCES Login_details (id_Login);

create table PatienthasDoctors(
Patient_id int not null,
Doctor_id int not null,
foreign key (Patient_id) references Patients (IdPatients) on delete cascade,
foreign key (Doctor_id) references Doctors (id_doctors) on delete cascade,
primary key(Patient_id, Doctor_id)
)

create table Diseases (
idDisease int Primary key,
Disease_name varchar(60) not null,
)

create table Patients_has_Diseases(
Patient_d_id int not null,
Diseases_id int not null,
foreign key (Patient_d_id) references Patients (IdPatients) on delete cascade,
foreign key (Diseases_id) references Diseases (idDisease) on delete cascade,
primary key(Patient_d_id, Diseases_id)
)

create table Symptoms(
idSymptoms int primary key,
Symptom varchar(70) not null
)

create table Diseases_has_Symptoms(
Symptoms_id int not null,
Diseases_S_id int not null,
foreign key (Symptoms_id) references Symptoms (idSymptoms) on delete cascade,
foreign key (Diseases_S_id) references Diseases (idDisease) on delete cascade,
primary key(Symptoms_id, Diseases_S_id)
)

create table History(
History_id int primary key,
History_details varchar(250) not null,
Visit_date date not null,
Patients_history_id int not null,
foreign key (Patients_history_id) references Patients (IdPatients) on delete cascade
)

create table Symptoms_has_History(
Symptoms_H_id int not null,
History_id int not null,
foreign key (Symptoms_H_id) references Symptoms (idSymptoms) on delete cascade,
foreign key (History_id) references History (History_id) on delete cascade,
primary key(Symptoms_H_id, History_id)
)

create table Medicines(
id_Medicine int primary key,
Medicine_name varchar(100) not null,
)

create table History_has_Medicines(
Medicine_id int not null,
History_M_id int not null,
foreign key (Medicine_id) references Medicines (id_Medicine) on delete cascade,
foreign key (History_M_id) references History (History_id) on delete cascade,
primary key(Medicine_id, History_M_id)
)

Drop table PatienthasDoctors

Alter table History
Add doctor_history_id int not null
ALTER TABLE History
ADD FOREIGN KEY (doctor_history_id) REFERENCES Doctors (id_doctors);

Drop table Patients_has_Diseases

create table Disease_has_History(
Disease_H_id int not null,
History_D_id int not null,
foreign key (Disease_H_id) references Diseases (idDisease) on delete cascade,
foreign key (History_D_id) references History (History_id) on delete cascade,
primary key(Disease_H_id, History_D_id)
)

alter table Login_details drop column Doctors_id

alter table Doctors drop column Specialty

insert into Patients(IdPatients, Patient_Name, Age, Weightkg, Height, Contactno, Is_Alive, Gender, Addresshome)
values (1, 'Zain Hassan', 21, 60.0, 6.0, 0318, 0, 'M', 'Defence karachi')
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(2, 'Laiba Qureshi', 21, 65.0, 6.0,0001,'F','Badban', 1)
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(3, 'Burhan Siddiqui', 22, 61.0, 5.0,0002,'M','Bahria', 0)
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(4, 'Lala Aneel', 20, 60.0, 7.0,0003,'M','Highland', 1)
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(5, 'Rafay Khalil', 18, 50.0, 5.7,0004,'M','Clifton', 1)
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(6, 'Lark Mendos', 32, 56.0, 6.2,0005,'F','Tower', 1)
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(7, 'Dua Zehra', 19, 49.0, 5.3,0006,'F','Defence', 1)
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(8, 'Mohit Kumar', 45, 56.0, 6.1,0007,'M','Gareebabad', 1)
insert into Patients(IdPatients,Patient_Name, Age, Weightkg, Height, Contactno, Gender, Addresshome, Is_Alive) 
values(9, 'Seema Shams', 29, 50.0, 5.6,0008,'F','Fb area', 1)

insert into Diseases(idDisease, Disease_name) values(1, 'cancer')
insert into Diseases(idDisease, Disease_name) values(2, 'asthma')
insert into Diseases(idDisease, Disease_name) values(3, 'diabetes')
insert into Diseases(idDisease, Disease_name) values(4, 'hepatitis')
insert into Diseases(idDisease, Disease_name) values(5, 'chickenpox')
insert into Diseases(idDisease, Disease_name) values(6, 'blood pressure')
insert into Diseases(idDisease, Disease_name) values(7, 'pneumonia')

insert into Specialties(id_specialty, Specialty) values(1, 'Dermatology')
insert into Specialties(id_specialty, Specialty) values(2, 'Paediatrics')
insert into Specialties(id_specialty, Specialty) values(3, 'Radiology')
insert into Specialties(id_specialty, Specialty) values(4, 'Neurology')
insert into Specialties(id_specialty, Specialty) values(5, 'Surgery')
insert into Specialties(id_specialty, Specialty) values(6, 'Internal medicine')
insert into Specialties(id_specialty, Specialty) values(7, 'Oncology')

insert into Symptoms(idSymptoms,Symptom) values(1, 'fever')
insert into Symptoms(idSymptoms,Symptom) values(2, 'fatigue')
insert into Symptoms(idSymptoms,Symptom) values(3, 'muscle pain')
insert into Symptoms(idSymptoms,Symptom) values(4, 'headache')
insert into Symptoms(idSymptoms,Symptom) values(5, 'nausea')
insert into Symptoms(idSymptoms,Symptom) values(6, 'bleeding')
insert into Symptoms(idSymptoms,Symptom) values(7, 'bowel changes')

insert into Medicines(id_Medicine, Medicine_name) values(1, 'panadol')
insert into Medicines(id_Medicine, Medicine_name) values(2, 'Insulin')
insert into Medicines(id_Medicine, Medicine_name) values(3, 'baclofen')
insert into Medicines(id_Medicine, Medicine_name) values(4, 'ventolin')
insert into Medicines(id_Medicine, Medicine_name) values(5, 'antacids')
insert into Medicines(id_Medicine, Medicine_name) values(6, 'rigix')

insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values('Adil Khan', 15, 'phD Pediatrics', 2, 3)
insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values( 'Zain Ali', 23, 'MD Radiology', 3, 4)
insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values('Talha Jawed', 7, 'Oncology Specialization', 7, 5)
insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values( 'Shafay Iqbal', 9, 'MD General Surgery', 5, 6)
insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values( 'Anooshay Irfan', 8, 'Fellowship Dermatology', 1, 7)
insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values( 'Taskeen Khan', 16, 'MD Neurology', 4, 8)
insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values( 'Uzma Talat', 8, 'Fellowship Dermatology', 1, 9)
insert into Doctors( Doc_Name, Experience, Education, doc_Specialty, doctor_loginid)
values( 'Faryal Jawaid', 17, 'FCPS Internal Medicine',6, 10)


ALTER TABLE Login_details
DROP COLUMN Username;

insert into Login_details(Pass, Designation) values( 'af06498', 'a')
insert into Login_details(Pass, Designation) values( 'zh06668', 'a')
insert into Login_details(Pass, Designation) values( 'ak06578', 'd')
insert into Login_details(Pass, Designation) values('za06543', 'd')
insert into Login_details(Pass, Designation) values( 'tj06512', 'd')
insert into Login_details(Pass, Designation) values('si06596', 'd')
insert into Login_details(Pass, Designation) values('ai06123', 'd')
insert into Login_details(Pass, Designation) values('tk06503', 'd')
insert into Login_details(Pass, Designation) values('ut06002', 'd')
insert into Login_details(Pass, Designation) values('fj06125', 'd')

insert into History(History_details, Visit_date, Patients_history_id, doctor_history_id)
values('light fever and headache', '11/05/22', 1, 9)
insert into History( History_details, Visit_date, Patients_history_id, doctor_history_id)
values('muscle pain and fatigue', '10/03/22', 2, 5)
insert into History(History_details, Visit_date, Patients_history_id, doctor_history_id)
values('nausea and rash', '09/02/21', 3, 2)
insert into History( History_details, Visit_date, Patients_history_id, doctor_history_id)
values('lower abdominal pain', '08/08/22', 4, 4)
insert into History( History_details, Visit_date, Patients_history_id, doctor_history_id)
values('burned nose', '11/04/22', 5, 6)
insert into History(History_details, Visit_date, Patients_history_id, doctor_history_id)
values('bleeding', '09/05/21', 6, 7)
insert into History( History_details, Visit_date, Patients_history_id, doctor_history_id)
values('Head ache and seizures', '11/07/22', 7, 7)
insert into History( History_details, Visit_date, Patients_history_id, doctor_history_id)
values('MRI reports checkup', '9/08/21', 8, 3)

insert into Disease_has_History values(7, 1);
insert into Disease_has_History values(4, 2);
insert into Disease_has_History values(5, 3);
insert into Disease_has_History values(1, 4);
insert into Disease_has_History values(3, 5);
insert into Disease_has_History values(2, 8);
insert into Disease_has_History values(6, 9);
insert into Disease_has_History values(1, 11);
insert into Disease_has_History values(3, 11);

insert into Diseases_has_Symptoms values(1, 7);
insert into Diseases_has_Symptoms values(2, 3);
insert into Diseases_has_Symptoms values(3, 2);
insert into Diseases_has_Symptoms values(4, 4);
insert into Diseases_has_Symptoms values(5, 6);
insert into Diseases_has_Symptoms values(6, 1);
insert into Diseases_has_Symptoms values(7, 1);
insert into Diseases_has_Symptoms values(2, 5);
insert into Diseases_has_Symptoms values(4, 2);


insert into Symptoms_has_History values(1, 1);
insert into Symptoms_has_History values(2, 5);
insert into Symptoms_has_History values(2, 3);
insert into Symptoms_has_History values(3, 8);
insert into Symptoms_has_History values(4, 8);
insert into Symptoms_has_History values(4, 2);
insert into Symptoms_has_History values(5, 9);
insert into Symptoms_has_History values(6, 9);
insert into Symptoms_has_History values(7, 4);
insert into Symptoms_has_History values(6, 11);

insert into History_has_Medicines values(1,1);
insert into History_has_Medicines values(2,2);
insert into History_has_Medicines values(3,3);
insert into History_has_Medicines values(4,4);
insert into History_has_Medicines values(5,5);
insert into History_has_Medicines values(6,8);
insert into History_has_Medicines values(5,9);
insert into History_has_Medicines values(1,9);
insert into History_has_Medicines values(3,11);


ALTER TABLE Doctors ADD Active varchar(50);
update Doctors set Active = 'True' where Active is NUll;

GO
create procedure addPatientDetails
    @patient_name varchar(50),
    @age int,
    @weight int,
	@height int,
    @contactno int,
    @isalive int,
	@Gender Varchar(10),
	@address Varchar(100)
AS
BEGIN

    SET NOCOUNT ON;

    insert into Patients (Patient_Name, Age, Weightkg, Height, Contactno, Is_Alive, Gender, Addresshome)
    values(@patient_name,@age,@weight, @height, @contactno, @isalive, @Gender, @address)

END
GO

insert into History(History_details, Visit_date, Patients_history_id, doctor_history_id)
values('fever', '11/07/22', 9, 8)
insert into Disease_has_History values(4, 12);
insert into Symptoms_has_History values(1, 12);
insert into History_has_Medicines values(6,12);

insert into History(History_details, Visit_date, Patients_history_id, doctor_history_id)
values('skin problems', '1/07/22', 10, 6)
insert into Disease_has_History values(4, 14);
insert into Symptoms_has_History values(5, 14);
insert into History_has_Medicines values(3,14);

insert into History(History_details, Visit_date, Patients_history_id, doctor_history_id)
values('internal bleeding', '11/07/22', 11, 4)
insert into Disease_has_History values(1, 15);
insert into Symptoms_has_History values(6, 15);
insert into History_has_Medicines values(5,15);

insert into History(History_details, Visit_date, Patients_history_id, doctor_history_id)
values('nausea', '11/28/22', 12, 9)
insert into Disease_has_History values(6, 16);
insert into Symptoms_has_History values(5, 16);
insert into History_has_Medicines values(4,16);

insert into Disease_has_History values(1, 20);
insert into Symptoms_has_History values(7, 20);
insert into History_has_Medicines values(5,20);

insert into Disease_has_History values(6, 21);
insert into Symptoms_has_History values(3, 21);
insert into History_has_Medicines values(1,21);

insert into Disease_has_History values(7, 22);
insert into Symptoms_has_History values(1, 22);

insert into Disease_has_History values(1, 23);
insert into Symptoms_has_History values(5, 23);
insert into History_has_Medicines values(3,23);

select * from Login_details;
select * from Doctors;
select * from Patients;
select * from History;
select * from Symptoms_has_History;
select * from Symptoms;
select * from Diseases;
select * from Diseases_has_Symptoms;
select * from Medicines;
select * from History_has_Medicines;
select * from Disease_has_History

